document.addEventListener('DOMContentLoaded', () =>{
    
    let logo = document.getElementById('logo');

    logo.addEventListener('click', () =>{
        window.location = "index.html";
    })

    document.querySelectorAll('.cardNoticias').forEach(link =>{
        link.addEventListener('click', () =>{
            let datas = link.getAttribute('data-link');
            window.location = datas;
        })
    });

    document.querySelectorAll('.option').forEach(link =>{
        link.addEventListener('click', () =>{
            let datas = link.getAttribute('data-link');
            window.location = datas;
        })
    });
})